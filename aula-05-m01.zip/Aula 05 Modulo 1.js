//EXEMPLO 1 WHILE


let num1 = 15;
let num2 = 20;

while (num1 < num2){
  console.log(`o ${num1} é menor`);
  num1++ //Aumenta um numero a cada vez que rodar(incremento)
}


// EXEMPLO 2


let num = 0;

while (num <= 10){
  num = prompt('digite um numero maior que 10');
}


// EXERCICIOS DE FIXAÇÃO 1 = Faça um programa que leia um nome de usuário e a sua senha e não aceite a senha igual ao nome do usuário, mostrando uma mensagem de erro e voltando a pedir as informações.


console.log()

console.log("Faca um cadastro de internet definindo seu usuario e senha")

console.log()

 var usuario = prompt("Digite seu nome de usuario: ")
 var senha = prompt("Digite sua senha de acesso: ")

   while (usuario == senha){
    console.log("O nome de usuario nao pode ser igual a senha de acesso");
    usuario = prompt("Digite seu nome de usuario: ")
    senha = prompt("Digite sua senha de acesso: ")

}

console.log(`Parabens ${usuario}, seu cadastro foi realizado com sucesso`);



/*exercicio de fixacao 2 = Faça um programa que leia e valide as seguintes informações:
Nome: maior que 3 caracteres;
Idade: entre 0 e 150;
Salário: maior que zero;
Estado Civil: 's', 'c', 'v', 'd';
*/

console.log("Seja bem vindo ao cadastro do inss")

var nome = prompt("digite seu nome: ")
while(nome.length < 3){
  console.log("nome invalido, precisa ter mais de 3 caracteres. digite novamente")
  nome = prompt("digite seu nome: ")
}

var idade = prompt("digite sua idade: ")
while (idade <=0 || idade > 150){
  console.log("idade invalida")
  idade = prompt("digite sua idade: ")
}

var salario = prompt("digite seu salario")
while(salario <= 0){
  console.log("salario invalido")
  salario = prompt("digite seu salario: ")
}

var estado = prompt("digite seu estado civil: ")
while(estado != "s" && estado != "c" && estado != "v" && estado != "d" ){
  console.log('Estado civil invalido')
  estado = prompt("digite seu estado civil: ")
}
  
  
  
